📊 Sales Data QA with Generative AI (RAG + LangChain + OpenAI)

This project allows you to ask natural language questions about structured (CSV), unstructured (JSON), and PDF-based sales data using OpenAI's GPT models with a Retrieval-Augmented Generation (RAG) pipeline powered by LangChain and FAISS.

Features

- Query CSV, JSON, and PDF sales data
- Powered by OpenAI GPT-3.5 and LangChain
- Embeddings stored locally with FAISS
- Gradio-based chat interface
- Plug-and-play `.env` support

---

🗂️ Project Structure

project-root/
│
├── D:/GenerativeAI/Structured_Unstructured/
│ ├── sales_data.csv
│ ├── sales_data.json
│ ├── sales_data.pdf
│ └── .env
│
├── app.py # Main Python script
├── requirements.txt # All dependencies
└── README.md # This file
