import os
import json
import pandas as pd
import gradio as gr
from dotenv import load_dotenv
from pathlib import Path
from langchain_core.documents import Document
from langchain_community.document_loaders import JSONLoader, PyPDFLoader
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA

# 1. Load environment variables from .env file
env_path = Path("D:/GenerativeAI/Structured_Unstructured/.env")
load_dotenv(env_path)

# 2. Get OpenAI API key from environment
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise ValueError(
        "OpenAI API key not found in .env file\n"
        f"Please add to {env_path}:\n"
        "OPENAI_API_KEY=your_api_key_here"
    )

# 3. Set file paths
data_dir = "D:/GenerativeAI/Structured_Unstructured"
csv_path = os.path.join(data_dir, "sales_data.csv")
json_path = os.path.join(data_dir, "sales_data.json")  # Updated to match your actual filename
pdf_path = os.path.join(data_dir, "sales_data.pdf")    # Updated to match your actual filename
index_path = os.path.join(data_dir, "sales_data_index")

# 🔁 Load and process documents (only once)
def load_documents():
    # CSV
    df = pd.read_csv(csv_path)
    structured_docs = [
        Document(page_content=json.dumps(row.to_dict()), metadata={"source": "csv"})
        for _, row in df.iterrows()
    ]

    # JSON - using text_content=False to handle dictionaries
    json_loader = JSONLoader(
        file_path=json_path,
        jq_schema=".[]",
        text_content=False  # Important for your JSON structure
    )
    raw_json_docs = json_loader.load()
    json_docs = [
        Document(page_content=json.dumps(doc.page_content), metadata=doc.metadata)
        for doc in raw_json_docs
    ]

    # PDF
    pdf_loader = PyPDFLoader(pdf_path)
    pdf_docs = pdf_loader.load()

    return structured_docs + json_docs + pdf_docs

# 🧠 Initialize vectorstore and QA chain
def init_qa_chain():
    if not os.path.exists(index_path):
        print("🔄 Creating vector index...")
        all_docs = load_documents()
        embedding = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
        db = FAISS.from_documents(all_docs, embedding)
        db.save_local(index_path)
    else:
        print("✅ Using existing index...")
        embedding = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
        db = FAISS.load_local(index_path, embedding, allow_dangerous_deserialization=True)
    
    retriever = db.as_retriever()
    llm = ChatOpenAI(
        model_name="gpt-3.5-turbo",
        temperature=0,
        openai_api_key=OPENAI_API_KEY
    )
    qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
    return qa_chain

# Initialize QA chain
try:
    qa_chain = init_qa_chain()
except Exception as e:
    print(f"❌ Error initializing QA chain: {e}")
    qa_chain = None

# 💬 Gradio Interface
def ask_question(query):
    if qa_chain is None:
        return "⚠️ System not initialized properly. Please check server logs."
    
    try:
        response = qa_chain({"query": query})
        return response["result"]
    except Exception as e:
        return f"❌ Error: {str(e)}"

interface = gr.Interface(
    fn=ask_question,
    inputs=gr.Textbox(label="Ask about your Sales Data", placeholder="What were our top products last quarter?"),
    outputs=gr.Textbox(label="AI Response"),
    title="📊 Sales Data QA with OpenAI + RAG",
    description="Query structured (CSV), unstructured (JSON), and PDF sales data using OpenAI + FAISS + LangChain.",

    examples=[
        ["What were the top 3 selling products?"],
        ["Show me Top 3 Customers"],
        ["List 3 customers aged 'Senior' who purchased Apple MacBook, along with their purchase amounts."],
        ["What insights can you provide from the Region Sales?"],
                ["Show me the total sales amount by year and highlight which year had the highest sales?"],
                ["What is the average sales amount for Male vs Female customers?"],
                ["Give a year-wise breakdown of total sales for the Electronics category in North America"],
                ["Which region had the highest number of customers?"],
                ["Generate a bar chart of total sales by product name."],
    ]
)

interface.launch()