import streamlit as st
from transformers import pipeline

# Load summarizer pipeline
summarizer = pipeline("summarization")

st.title("📝 Text Summarizer App")

text = st.text_area("Paste your long text here:", height=300)

if st.button("Summarize"):
    if len(text.strip()) < 100:
        st.warning("Please enter at least 100 characters.")
    else:
        with st.spinner("Generating summary..."):
            summary = summarizer(text, max_length=130, min_length=30, do_sample=False)
            st.subheader("📌 Summary")
            st.write(summary[0]['summary_text'])
