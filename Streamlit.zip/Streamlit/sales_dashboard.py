import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("📊 Sales Dashboard")

# File uploader
uploaded_file = st.file_uploader("Upload your sales CSV file", type="csv")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)

    st.write("### 🗃️ Raw Data", df)

    # Country selection
    countries = df["Country"].unique()
    country = st.selectbox("Select Country", countries)

    # Filter data
    filtered_df = df[df["Country"] == country]

    # Plot sales trend
    st.write(f"### 📈 Sales Trend for {country}")
    fig, ax = plt.subplots()
    ax.plot(filtered_df["Month"], filtered_df["Sales"], marker='o')
    ax.set_xlabel("Month")
    ax.set_ylabel("Sales")
    ax.set_title(f"{country} Sales Over Time")
    st.pyplot(fig)
