# 🎬 Hollywood Movies Chatbot

An interactive chatbot built with Python, OpenAI GPT, and Gradio that answers questions about Hollywood movies using a custom dataset.
It also collects basic user information (name, phone, email, location) and stores it in an Excel file.

## 🚀 Features

✅ Answers only from your dataset (no hallucinations).
✅ Collects user details and saves to `user_info.xlsx`.
✅ Examples of supported queries:

* Who directed Titanic?
* Which movie won the most Oscars?
* Which movies are available on Netflix?
  ✅ Simple web UI with Gradio.
  ✅ Help button with example prompts.

## 📄 How it Works

1️⃣ Loads your Hollywood movie dataset from Excel.
2️⃣ Starts Gradio app in browser.
3️⃣ Collects user details step-by-step.
4️⃣ Sends movie questions to GPT with the dataset as context.
5️⃣ Saves all user details to `user_info.xlsx`.
